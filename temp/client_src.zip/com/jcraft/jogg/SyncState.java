package com.jcraft.jogg;

public class SyncState {
	public byte[] data;
	int storage;
	int fill;
	int returned;
	int unsynced;
	int headerbytes;
	int bodybytes;
	private Page pageseek = new Page();
	private byte[] chksum = new byte[4];

	public int clear() {
		this.data = null;
		return 0;
	}

	public int buffer(int i1) {
		if(this.returned != 0) {
			this.fill -= this.returned;
			if(this.fill > 0) {
				System.arraycopy(this.data, this.returned, this.data, 0, this.fill);
			}

			this.returned = 0;
		}

		if(i1 > this.storage - this.fill) {
			i1 = i1 + this.fill + 4096;
			if(this.data != null) {
				byte[] b2 = new byte[i1];
				System.arraycopy(this.data, 0, b2, 0, this.data.length);
				this.data = b2;
			} else {
				this.data = new byte[i1];
			}

			this.storage = i1;
		}

		return this.fill;
	}

	public int wrote(int i1) {
		if(this.fill + i1 > this.storage) {
			return -1;
		} else {
			this.fill += i1;
			return 0;
		}
	}

	public int pageseek(Page page1) {
		int i2 = this.returned;
		int i3 = this.fill - this.returned;
		int i5;
		int i7;
		if(this.headerbytes == 0) {
			if(i3 < 27) {
				return 0;
			}

			if(this.data[i2] != 79 || this.data[i2 + 1] != 103 || this.data[i2 + 2] != 103 || this.data[i2 + 3] != 83) {
				this.headerbytes = 0;
				this.bodybytes = 0;
				i7 = 0;

				for(i5 = 0; i5 < i3 - 1; ++i5) {
					if(this.data[i2 + 1 + i5] == 79) {
						i7 = i2 + 1 + i5;
						break;
					}
				}

				if(i7 == 0) {
					i7 = this.fill;
				}

				this.returned = i7;
				return -(i7 - i2);
			}

			int i4 = (this.data[i2 + 26] & 255) + 27;
			if(i3 < i4) {
				return 0;
			}

			for(i5 = 0; i5 < (this.data[i2 + 26] & 255); ++i5) {
				this.bodybytes += this.data[i2 + 27 + i5] & 255;
			}

			this.headerbytes = i4;
		}

		if(this.bodybytes + this.headerbytes > i3) {
			return 0;
		} else {
			byte[] b8 = this.chksum;
			synchronized(this.chksum) {
				System.arraycopy(this.data, i2 + 22, this.chksum, 0, 4);
				this.data[i2 + 22] = 0;
				this.data[i2 + 23] = 0;
				this.data[i2 + 24] = 0;
				this.data[i2 + 25] = 0;
				Page page9 = this.pageseek;
				this.pageseek.header_base = this.data;
				page9.header = i2;
				page9.header_len = this.headerbytes;
				page9.body_base = this.data;
				page9.body = i2 + this.headerbytes;
				page9.body_len = this.bodybytes;
				page9.checksum();
				if(this.chksum[0] != this.data[i2 + 22] || this.chksum[1] != this.data[i2 + 23] || this.chksum[2] != this.data[i2 + 24] || this.chksum[3] != this.data[i2 + 25]) {
					System.arraycopy(this.chksum, 0, this.data, i2 + 22, 4);
					this.headerbytes = 0;
					this.bodybytes = 0;
					i7 = 0;

					for(i5 = 0; i5 < i3 - 1; ++i5) {
						if(this.data[i2 + 1 + i5] == 79) {
							i7 = i2 + 1 + i5;
							break;
						}
					}

					if(i7 == 0) {
						i7 = this.fill;
					}

					this.returned = i7;
					return -(i7 - i2);
				}
			}

			i2 = this.returned;
			if(page1 != null) {
				page1.header_base = this.data;
				page1.header = i2;
				page1.header_len = this.headerbytes;
				page1.body_base = this.data;
				page1.body = i2 + this.headerbytes;
				page1.body_len = this.bodybytes;
			}

			this.unsynced = 0;
			this.returned += i3 = this.headerbytes + this.bodybytes;
			this.headerbytes = 0;
			this.bodybytes = 0;
			return i3;
		}
	}

	public int pageout(Page page1) {
		do {
			int i2;
			if((i2 = this.pageseek(page1)) > 0) {
				return 1;
			}

			if(i2 == 0) {
				return 0;
			}
		} while(this.unsynced != 0);

		this.unsynced = 1;
		return -1;
	}

	public int reset() {
		this.fill = 0;
		this.returned = 0;
		this.unsynced = 0;
		this.headerbytes = 0;
		this.bodybytes = 0;
		return 0;
	}

	public void init() {
	}

	public int getDataOffset() {
		return this.returned;
	}

	public int getBufferOffset() {
		return this.fill;
	}
}
