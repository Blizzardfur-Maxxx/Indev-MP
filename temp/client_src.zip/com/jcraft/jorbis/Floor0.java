package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

import util.MathHelper;

class Floor0 extends FuncFloor {
	float[] lsp = null;

	void pack(Object object1, Buffer buffer2) {
		Floor0$InfoFloor0 floor0$InfoFloor04 = (Floor0$InfoFloor0)object1;
		buffer2.write(floor0$InfoFloor04.order, 8);
		buffer2.write(floor0$InfoFloor04.rate, 16);
		buffer2.write(floor0$InfoFloor04.barkmap, 16);
		buffer2.write(floor0$InfoFloor04.ampbits, 6);
		buffer2.write(floor0$InfoFloor04.ampdB, 8);
		buffer2.write(floor0$InfoFloor04.numbooks - 1, 4);

		for(int i3 = 0; i3 < floor0$InfoFloor04.numbooks; ++i3) {
			buffer2.write(floor0$InfoFloor04.books[i3], 8);
		}

	}

	Object unpack(Info info1, Buffer buffer2) {
		Floor0$InfoFloor0 floor0$InfoFloor03;
		(floor0$InfoFloor03 = new Floor0$InfoFloor0(this)).order = buffer2.read(8);
		floor0$InfoFloor03.rate = buffer2.read(16);
		floor0$InfoFloor03.barkmap = buffer2.read(16);
		floor0$InfoFloor03.ampbits = buffer2.read(6);
		floor0$InfoFloor03.ampdB = buffer2.read(8);
		floor0$InfoFloor03.numbooks = buffer2.read(4) + 1;
		if(floor0$InfoFloor03.order > 0 && floor0$InfoFloor03.rate > 0 && floor0$InfoFloor03.barkmap > 0 && floor0$InfoFloor03.numbooks > 0) {
			for(int i4 = 0; i4 < floor0$InfoFloor03.numbooks; ++i4) {
				floor0$InfoFloor03.books[i4] = buffer2.read(8);
				if(floor0$InfoFloor03.books[i4] < 0 || floor0$InfoFloor03.books[i4] >= info1.books) {
					return null;
				}
			}

			return floor0$InfoFloor03;
		} else {
			return null;
		}
	}

	Object look(DspState dspState1, InfoMode infoMode2, Object object3) {
		Info info6 = dspState1.vi;
		Floor0$InfoFloor0 floor0$InfoFloor09 = (Floor0$InfoFloor0)object3;
		Floor0$LookFloor0 floor0$LookFloor04;
		(floor0$LookFloor04 = new Floor0$LookFloor0(this)).m = floor0$InfoFloor09.order;
		floor0$LookFloor04.n = info6.blocksizes[infoMode2.blockflag] / 2;
		floor0$LookFloor04.ln = floor0$InfoFloor09.barkmap;
		floor0$LookFloor04.vi = floor0$InfoFloor09;
		floor0$LookFloor04.lpclook.init(floor0$LookFloor04.ln, floor0$LookFloor04.m);
		float f7 = (float)floor0$LookFloor04.ln / toBARK((float)((double)floor0$InfoFloor09.rate / 2.0D));
		floor0$LookFloor04.linearmap = new int[floor0$LookFloor04.n];

		for(int i8 = 0; i8 < floor0$LookFloor04.n; ++i8) {
			int i5;
			if((i5 = MathHelper.floor_float(toBARK((float)((double)floor0$InfoFloor09.rate / 2.0D / (double)floor0$LookFloor04.n * (double)i8)) * f7)) >= floor0$LookFloor04.ln) {
				i5 = floor0$LookFloor04.ln;
			}

			floor0$LookFloor04.linearmap[i8] = i5;
		}

		return floor0$LookFloor04;
	}

	static float toBARK(float f0) {
		return (float)(13.1D * Math.atan(7.4E-4D * (double)f0) + 2.24D * Math.atan((double)(f0 * f0) * 1.85E-8D) + 1.0E-4D * (double)f0);
	}

	Object state(Object object1) {
		Floor0$EchstateFloor0 floor0$EchstateFloor02 = new Floor0$EchstateFloor0(this);
		Floor0$InfoFloor0 floor0$InfoFloor03 = (Floor0$InfoFloor0)object1;
		floor0$EchstateFloor02.codewords = new int[floor0$InfoFloor03.order];
		floor0$EchstateFloor02.curve = new float[floor0$InfoFloor03.barkmap];
		floor0$EchstateFloor02.frameno = -1L;
		return floor0$EchstateFloor02;
	}

	void free_info(Object object1) {
	}

	void free_look(Object object1) {
	}

	void free_state(Object object1) {
	}

	int forward(Block block1, Object object2, float[] f3, float[] f4, Object object5) {
		return 0;
	}

	int inverse(Block block1, Object object2, float[] f3) {
		Floor0$LookFloor0 floor0$LookFloor012;
		Floor0$InfoFloor0 floor0$InfoFloor04 = (floor0$LookFloor012 = (Floor0$LookFloor0)object2).vi;
		int i5;
		if((i5 = block1.opb.read(floor0$InfoFloor04.ampbits)) > 0) {
			int i6 = (1 << floor0$InfoFloor04.ampbits) - 1;
			float f13 = (float)i5 / (float)i6 * (float)floor0$InfoFloor04.ampdB;
			if((i6 = block1.opb.read(Util.ilog(floor0$InfoFloor04.numbooks))) != -1 && i6 < floor0$InfoFloor04.numbooks) {
				synchronized(this) {
					if(this.lsp != null && this.lsp.length >= floor0$LookFloor012.m) {
						for(int i8 = 0; i8 < floor0$LookFloor012.m; ++i8) {
							this.lsp[i8] = 0.0F;
						}
					} else {
						this.lsp = new float[floor0$LookFloor012.m];
					}

					CodeBook codeBook15 = block1.vd.fullbooks[floor0$InfoFloor04.books[i6]];
					float f14 = 0.0F;

					int i9;
					for(i9 = 0; i9 < floor0$LookFloor012.m; ++i9) {
						f3[i9] = 0.0F;
					}

					int i11;
					for(i9 = 0; i9 < floor0$LookFloor012.m; i9 += codeBook15.dim) {
						if(codeBook15.decodevs(this.lsp, i9, block1.opb, 1, -1) == -1) {
							for(i11 = 0; i11 < floor0$LookFloor012.n; ++i11) {
								f3[i11] = 0.0F;
							}

							return 0;
						}
					}

					for(i9 = 0; i9 < floor0$LookFloor012.m; f14 = this.lsp[i9 - 1]) {
						for(i11 = 0; i11 < codeBook15.dim; ++i9) {
							this.lsp[i9] += f14;
							++i11;
						}
					}

					Lsp.lsp_to_curve(f3, floor0$LookFloor012.linearmap, floor0$LookFloor012.n, floor0$LookFloor012.ln, this.lsp, floor0$LookFloor012.m, f13, (float)floor0$InfoFloor04.ampdB);
					return 1;
				}
			}
		}

		return 0;
	}

	Object inverse1(Block block1, Object object2, Object object3) {
		Floor0$LookFloor0 floor0$LookFloor09;
		Floor0$InfoFloor0 floor0$InfoFloor04 = (floor0$LookFloor09 = (Floor0$LookFloor0)object2).vi;
		float[] f5 = null;
		if(object3 instanceof float[]) {
			f5 = (float[])object3;
		}

		int i10;
		if((i10 = block1.opb.read(floor0$InfoFloor04.ampbits)) > 0) {
			int i6 = (1 << floor0$InfoFloor04.ampbits) - 1;
			float f11 = (float)i10 / (float)i6 * (float)floor0$InfoFloor04.ampdB;
			if((i6 = block1.opb.read(Util.ilog(floor0$InfoFloor04.numbooks))) != -1 && i6 < floor0$InfoFloor04.numbooks) {
				CodeBook codeBook12 = block1.vd.fullbooks[floor0$InfoFloor04.books[i6]];
				float f13 = 0.0F;
				int i7;
				if(f5 != null && f5.length >= floor0$LookFloor09.m + 1) {
					for(i7 = 0; i7 < f5.length; ++i7) {
						f5[i7] = 0.0F;
					}
				} else {
					f5 = new float[floor0$LookFloor09.m + 1];
				}

				for(i7 = 0; i7 < floor0$LookFloor09.m; i7 += codeBook12.dim) {
					if(codeBook12.decodev_set(f5, i7, block1.opb, codeBook12.dim) == -1) {
						return null;
					}
				}

				for(i7 = 0; i7 < floor0$LookFloor09.m; f13 = f5[i7 - 1]) {
					for(int i8 = 0; i8 < codeBook12.dim; ++i7) {
						f5[i7] += f13;
						++i8;
					}
				}

				f5[floor0$LookFloor09.m] = f11;
				return f5;
			}
		}

		return null;
	}

	int inverse2(Block block1, Object object2, Object object3, float[] f4) {
		Floor0$LookFloor0 floor0$LookFloor06;
		Floor0$InfoFloor0 floor0$InfoFloor07 = (floor0$LookFloor06 = (Floor0$LookFloor0)object2).vi;
		if(object3 != null) {
			float[] f9;
			float f5 = (f9 = (float[])object3)[floor0$LookFloor06.m];
			Lsp.lsp_to_curve(f4, floor0$LookFloor06.linearmap, floor0$LookFloor06.n, floor0$LookFloor06.ln, f9, floor0$LookFloor06.m, f5, (float)floor0$InfoFloor07.ampdB);
			return 1;
		} else {
			for(int i8 = 0; i8 < floor0$LookFloor06.n; ++i8) {
				f4[i8] = 0.0F;
			}

			return 0;
		}
	}

	static float fromdB(float f0) {
		return (float)Math.exp((double)f0 * 0.11512925D);
	}

	static void lsp_to_lpc(float[] f0, float[] f1, int i2) {
		int i4;
		float[] f5 = new float[i4 = i2 / 2];
		float[] f6 = new float[i4];
		float[] f8 = new float[i4 + 1];
		float[] f9 = new float[i4 + 1];
		float[] f11 = new float[i4];
		float[] f12 = new float[i4];

		int i3;
		for(i3 = 0; i3 < i4; ++i3) {
			f5[i3] = (float)(-2.0D * Math.cos((double)f0[i3 << 1]));
			f6[i3] = (float)(-2.0D * Math.cos((double)f0[(i3 << 1) + 1]));
		}

		int i14;
		for(i14 = 0; i14 < i4; ++i14) {
			f8[i14] = 0.0F;
			f9[i14] = 1.0F;
			f11[i14] = 0.0F;
			f12[i14] = 1.0F;
		}

		f9[i14] = 1.0F;
		f8[i14] = 1.0F;

		for(i3 = 1; i3 < i2 + 1; ++i3) {
			float f10 = 0.0F;
			float f7 = 0.0F;

			for(i14 = 0; i14 < i4; ++i14) {
				float f13 = f5[i14] * f9[i14] + f8[i14];
				f8[i14] = f9[i14];
				f9[i14] = f7;
				f7 += f13;
				f13 = f6[i14] * f12[i14] + f11[i14];
				f11[i14] = f12[i14];
				f12[i14] = f10;
				f10 += f13;
			}

			f1[i3 - 1] = (f7 + f9[i14] + f10 - f8[i14]) / 2.0F;
			f9[i14] = f7;
			f8[i14] = f10;
		}

	}

	static void lpc_to_curve(float[] f0, float[] f1, float f2, Floor0$LookFloor0 floor0$LookFloor03, String string4, int i5) {
		float[] f7 = new float[Math.max(floor0$LookFloor03.ln << 1, (floor0$LookFloor03.m << 1) + 2)];
		int i6;
		if(f2 == 0.0F) {
			for(i6 = 0; i6 < floor0$LookFloor03.n; ++i6) {
				f0[i6] = 0.0F;
			}

		} else {
			floor0$LookFloor03.lpclook.lpc_to_curve(f7, f1, f2);

			for(i6 = 0; i6 < floor0$LookFloor03.n; ++i6) {
				f0[i6] = f7[floor0$LookFloor03.linearmap[i6]];
			}

		}
	}
}
