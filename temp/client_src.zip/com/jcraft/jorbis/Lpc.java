package com.jcraft.jorbis;

class Lpc {
	Drft fft = new Drft();
	int ln;
	int m;

	static float lpc_from_data(float[] f0, float[] f1, int i2, int i3) {
		float[] f4 = new float[i3 + 1];

		int i5;
		int i6;
		float f7;
		for(i6 = i3 + 1; i6-- != 0; f4[i6] = f7) {
			f7 = 0.0F;

			for(i5 = i6; i5 < i2; ++i5) {
				f7 += f0[i5] * f0[i5 - i6];
			}
		}

		float f8 = f4[0];

		for(i5 = 0; i5 < i3; ++i5) {
			f7 = -f4[i5 + 1];
			if(f8 == 0.0F) {
				for(i2 = 0; i2 < i3; ++i2) {
					f1[i2] = 0.0F;
				}

				return 0.0F;
			}

			for(i6 = 0; i6 < i5; ++i6) {
				f7 -= f1[i6] * f4[i5 - i6];
			}

			f7 /= f8;
			f1[i5] = f7;

			for(i6 = 0; i6 < i5 / 2; ++i6) {
				float f9 = f1[i6];
				f1[i6] += f7 * f1[i5 - 1 - i6];
				f1[i5 - 1 - i6] += f7 * f9;
			}

			if(i5 % 2 != 0) {
				f1[i6] += f1[i6] * f7;
			}

			f8 = (float)((double)f8 * (1.0D - (double)(f7 * f7)));
		}

		return f8;
	}

	float lpc_from_curve(float[] f1, float[] f2) {
		int i3 = this.ln;
		float[] f4 = new float[this.ln + i3];
		float f5 = (float)(0.5D / (double)i3);

		int i6;
		for(i6 = 0; i6 < i3; ++i6) {
			f4[i6 << 1] = f1[i6] * f5;
			f4[(i6 << 1) + 1] = 0.0F;
		}

		f4[(i3 << 1) - 1] = f1[i3 - 1] * f5;
		i3 <<= 1;
		this.fft.backward(f4);
		i6 = 0;

		for(int i7 = i3 / 2; i6 < i3 / 2; f4[i7++] = f5) {
			f5 = f4[i6];
			f4[i6++] = f4[i7];
		}

		return lpc_from_data(f4, f2, i3, this.m);
	}

	void init(int i1, int i2) {
		this.ln = i1;
		this.m = i2;
		this.fft.init(i1 << 1);
	}

	void clear() {
		this.fft.clear();
	}

	static float FAST_HYPOT(float f0, float f1) {
		return (float)Math.sqrt((double)(f0 * f0 + f1 * f1));
	}

	void lpc_to_curve(float[] f1, float[] f2, float f3) {
		int i4;
		for(i4 = 0; i4 < this.ln << 1; ++i4) {
			f1[i4] = 0.0F;
		}

		if(f3 != 0.0F) {
			for(i4 = 0; i4 < this.m; ++i4) {
				f1[(i4 << 1) + 1] = f2[i4] / (4.0F * f3);
				f1[(i4 << 1) + 2] = -f2[i4] / (4.0F * f3);
			}

			this.fft.backward(f1);
			i4 = this.ln << 1;
			float f7 = (float)(1.0D / (double)f3);
			f1[0] = (float)(1.0D / (double)(f1[0] * 2.0F + f7));

			for(int i8 = 1; i8 < this.ln; ++i8) {
				float f5 = f1[i8] + f1[i4 - i8];
				float f6 = f1[i8] - f1[i4 - i8];
				f5 += f7;
				f1[i8] = (float)(1.0D / (double)FAST_HYPOT(f5, f6));
			}

		}
	}
}
