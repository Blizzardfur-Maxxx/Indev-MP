package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class Mapping0 extends FuncMapping {
	static int seq = 0;
	float[][] pcmbundle = null;
	int[] zerobundle = null;
	int[] nonzero = null;
	Object[] floormemo = null;

	void free_info(Object object1) {
	}

	void free_look(Object object1) {
	}

	Object look(DspState dspState1, InfoMode infoMode2, Object object3) {
		Info info4 = dspState1.vi;
		Mapping0$LookMapping0 mapping0$LookMapping05;
		Mapping0$InfoMapping0 mapping0$InfoMapping010 = (mapping0$LookMapping05 = new Mapping0$LookMapping0(this)).map = (Mapping0$InfoMapping0)object3;
		mapping0$LookMapping05.mode = infoMode2;
		mapping0$LookMapping05.time_look = new Object[mapping0$InfoMapping010.submaps];
		mapping0$LookMapping05.floor_look = new Object[mapping0$InfoMapping010.submaps];
		mapping0$LookMapping05.residue_look = new Object[mapping0$InfoMapping010.submaps];
		mapping0$LookMapping05.time_func = new FuncTime[mapping0$InfoMapping010.submaps];
		mapping0$LookMapping05.floor_func = new FuncFloor[mapping0$InfoMapping010.submaps];
		mapping0$LookMapping05.residue_func = new FuncResidue[mapping0$InfoMapping010.submaps];

		for(int i6 = 0; i6 < mapping0$InfoMapping010.submaps; ++i6) {
			int i7 = mapping0$InfoMapping010.timesubmap[i6];
			int i8 = mapping0$InfoMapping010.floorsubmap[i6];
			int i9 = mapping0$InfoMapping010.residuesubmap[i6];
			mapping0$LookMapping05.time_func[i6] = FuncTime.time_P[info4.time_type[i7]];
			mapping0$LookMapping05.time_look[i6] = mapping0$LookMapping05.time_func[i6].look(dspState1, infoMode2, info4.time_param[i7]);
			mapping0$LookMapping05.floor_func[i6] = FuncFloor.floor_P[info4.floor_type[i8]];
			mapping0$LookMapping05.floor_look[i6] = mapping0$LookMapping05.floor_func[i6].look(dspState1, infoMode2, info4.floor_param[i8]);
			mapping0$LookMapping05.residue_func[i6] = FuncResidue.residue_P[info4.residue_type[i9]];
			mapping0$LookMapping05.residue_look[i6] = mapping0$LookMapping05.residue_func[i6].look(dspState1, infoMode2, info4.residue_param[i9]);
		}

		mapping0$LookMapping05.ch = info4.channels;
		return mapping0$LookMapping05;
	}

	void pack(Info info1, Object object2, Buffer buffer3) {
		Mapping0$InfoMapping0 mapping0$InfoMapping05;
		if((mapping0$InfoMapping05 = (Mapping0$InfoMapping0)object2).submaps > 1) {
			buffer3.write(1, 1);
			buffer3.write(mapping0$InfoMapping05.submaps - 1, 4);
		} else {
			buffer3.write(0, 1);
		}

		int i4;
		if(mapping0$InfoMapping05.coupling_steps > 0) {
			buffer3.write(1, 1);
			buffer3.write(mapping0$InfoMapping05.coupling_steps - 1, 8);

			for(i4 = 0; i4 < mapping0$InfoMapping05.coupling_steps; ++i4) {
				buffer3.write(mapping0$InfoMapping05.coupling_mag[i4], Util.ilog2(info1.channels));
				buffer3.write(mapping0$InfoMapping05.coupling_ang[i4], Util.ilog2(info1.channels));
			}
		} else {
			buffer3.write(0, 1);
		}

		buffer3.write(0, 2);
		if(mapping0$InfoMapping05.submaps > 1) {
			for(i4 = 0; i4 < info1.channels; ++i4) {
				buffer3.write(mapping0$InfoMapping05.chmuxlist[i4], 4);
			}
		}

		for(i4 = 0; i4 < mapping0$InfoMapping05.submaps; ++i4) {
			buffer3.write(mapping0$InfoMapping05.timesubmap[i4], 8);
			buffer3.write(mapping0$InfoMapping05.floorsubmap[i4], 8);
			buffer3.write(mapping0$InfoMapping05.residuesubmap[i4], 8);
		}

	}

	Object unpack(Info info1, Buffer buffer2) {
		Mapping0$InfoMapping0 mapping0$InfoMapping03 = new Mapping0$InfoMapping0(this);
		if(buffer2.read(1) != 0) {
			mapping0$InfoMapping03.submaps = buffer2.read(4) + 1;
		} else {
			mapping0$InfoMapping03.submaps = 1;
		}

		int i4;
		if(buffer2.read(1) != 0) {
			mapping0$InfoMapping03.coupling_steps = buffer2.read(8) + 1;

			for(i4 = 0; i4 < mapping0$InfoMapping03.coupling_steps; ++i4) {
				int i5 = mapping0$InfoMapping03.coupling_mag[i4] = buffer2.read(Util.ilog2(info1.channels));
				int i6 = mapping0$InfoMapping03.coupling_ang[i4] = buffer2.read(Util.ilog2(info1.channels));
				if(i5 < 0 || i6 < 0 || i5 == i6 || i5 >= info1.channels || i6 >= info1.channels) {
					mapping0$InfoMapping03.free();
					return null;
				}
			}
		}

		if(buffer2.read(2) > 0) {
			mapping0$InfoMapping03.free();
			return null;
		} else {
			if(mapping0$InfoMapping03.submaps > 1) {
				for(i4 = 0; i4 < info1.channels; ++i4) {
					mapping0$InfoMapping03.chmuxlist[i4] = buffer2.read(4);
					if(mapping0$InfoMapping03.chmuxlist[i4] >= mapping0$InfoMapping03.submaps) {
						mapping0$InfoMapping03.free();
						return null;
					}
				}
			}

			for(i4 = 0; i4 < mapping0$InfoMapping03.submaps; ++i4) {
				mapping0$InfoMapping03.timesubmap[i4] = buffer2.read(8);
				if(mapping0$InfoMapping03.timesubmap[i4] >= info1.times) {
					mapping0$InfoMapping03.free();
					return null;
				}

				mapping0$InfoMapping03.floorsubmap[i4] = buffer2.read(8);
				if(mapping0$InfoMapping03.floorsubmap[i4] >= info1.floors) {
					mapping0$InfoMapping03.free();
					return null;
				}

				mapping0$InfoMapping03.residuesubmap[i4] = buffer2.read(8);
				if(mapping0$InfoMapping03.residuesubmap[i4] >= info1.residues) {
					mapping0$InfoMapping03.free();
					return null;
				}
			}

			return mapping0$InfoMapping03;
		}
	}

	synchronized int inverse(Block block1, Object object2) {
		DspState dspState3 = block1.vd;
		Info info4 = block1.vd.vi;
		Mapping0$LookMapping0 mapping0$LookMapping014;
		Mapping0$InfoMapping0 mapping0$InfoMapping05 = (mapping0$LookMapping014 = (Mapping0$LookMapping0)object2).map;
		InfoMode infoMode6 = mapping0$LookMapping014.mode;
		int i7 = block1.pcmend = info4.blocksizes[block1.W];
		float[] f15 = dspState3.window[block1.W][block1.lW][block1.nW][infoMode6.windowtype];
		if(this.pcmbundle == null || this.pcmbundle.length < info4.channels) {
			this.pcmbundle = new float[info4.channels][];
			this.nonzero = new int[info4.channels];
			this.zerobundle = new int[info4.channels];
			this.floormemo = new Object[info4.channels];
		}

		int i8;
		float[] f9;
		int i10;
		int i11;
		for(i8 = 0; i8 < info4.channels; ++i8) {
			f9 = block1.pcm[i8];
			i10 = mapping0$InfoMapping05.chmuxlist[i8];
			this.floormemo[i8] = mapping0$LookMapping014.floor_func[i10].inverse1(block1, mapping0$LookMapping014.floor_look[i10], this.floormemo[i8]);
			if(this.floormemo[i8] != null) {
				this.nonzero[i8] = 1;
			} else {
				this.nonzero[i8] = 0;
			}

			for(i11 = 0; i11 < i7 / 2; ++i11) {
				f9[i11] = 0.0F;
			}
		}

		for(i8 = 0; i8 < mapping0$InfoMapping05.coupling_steps; ++i8) {
			if(this.nonzero[mapping0$InfoMapping05.coupling_mag[i8]] != 0 || this.nonzero[mapping0$InfoMapping05.coupling_ang[i8]] != 0) {
				this.nonzero[mapping0$InfoMapping05.coupling_mag[i8]] = 1;
				this.nonzero[mapping0$InfoMapping05.coupling_ang[i8]] = 1;
			}
		}

		for(i8 = 0; i8 < mapping0$InfoMapping05.submaps; ++i8) {
			int i16 = 0;

			for(i10 = 0; i10 < info4.channels; ++i10) {
				if(mapping0$InfoMapping05.chmuxlist[i10] == i8) {
					if(this.nonzero[i10] != 0) {
						this.zerobundle[i16] = 1;
					} else {
						this.zerobundle[i16] = 0;
					}

					this.pcmbundle[i16++] = block1.pcm[i10];
				}
			}

			mapping0$LookMapping014.residue_func[i8].inverse(block1, mapping0$LookMapping014.residue_look[i8], this.pcmbundle, this.zerobundle, i16);
		}

		for(i8 = mapping0$InfoMapping05.coupling_steps - 1; i8 >= 0; --i8) {
			f9 = block1.pcm[mapping0$InfoMapping05.coupling_mag[i8]];
			float[] f17 = block1.pcm[mapping0$InfoMapping05.coupling_ang[i8]];

			for(i11 = 0; i11 < i7 / 2; ++i11) {
				float f12 = f9[i11];
				float f13 = f17[i11];
				if(f12 > 0.0F) {
					if(f13 > 0.0F) {
						f9[i11] = f12;
						f17[i11] = f12 - f13;
					} else {
						f17[i11] = f12;
						f9[i11] = f12 + f13;
					}
				} else if(f13 > 0.0F) {
					f9[i11] = f12;
					f17[i11] = f12 + f13;
				} else {
					f17[i11] = f12;
					f9[i11] = f12 - f13;
				}
			}
		}

		for(i8 = 0; i8 < info4.channels; ++i8) {
			f9 = block1.pcm[i8];
			i10 = mapping0$InfoMapping05.chmuxlist[i8];
			mapping0$LookMapping014.floor_func[i10].inverse2(block1, mapping0$LookMapping014.floor_look[i10], this.floormemo[i8], f9);
		}

		for(i8 = 0; i8 < info4.channels; ++i8) {
			f9 = block1.pcm[i8];
			((Mdct)dspState3.transform[block1.W][0]).backward(f9, f9);
		}

		for(i8 = 0; i8 < info4.channels; ++i8) {
			f9 = block1.pcm[i8];
			if(this.nonzero[i8] != 0) {
				for(i10 = 0; i10 < i7; ++i10) {
					f9[i10] *= f15[i10];
				}
			} else {
				for(i10 = 0; i10 < i7; ++i10) {
					f9[i10] = 0.0F;
				}
			}
		}

		return 0;
	}
}
