package com.jcraft.jorbis;

class Mdct {
	int n;
	int log2n;
	float[] trig;
	int[] bitrev;
	float scale;
	float[] _x = new float[1024];
	float[] _w = new float[1024];

	void init(int i1) {
		this.bitrev = new int[i1 / 4];
		this.trig = new float[i1 + i1 / 4];
		this.log2n = (int)Math.rint(Math.log((double)i1) / Math.log(2.0D));
		this.n = i1;
		int i2;
		int i3 = (i2 = 0 + i1 / 2) + 1;
		int i4;
		int i5 = (i4 = i2 + i1 / 2) + 1;

		int i6;
		for(i6 = 0; i6 < i1 / 4; ++i6) {
			this.trig[0 + (i6 << 1)] = (float)Math.cos(3.141592653589793D / (double)i1 * (double)(i6 * 4));
			this.trig[1 + (i6 << 1)] = (float)(-Math.sin(3.141592653589793D / (double)i1 * (double)(i6 * 4)));
			this.trig[i2 + (i6 << 1)] = (float)Math.cos(3.141592653589793D / (double)(i1 * 2) * (double)(i6 * 2 + 1));
			this.trig[i3 + (i6 << 1)] = (float)Math.sin(3.141592653589793D / (double)(i1 * 2) * (double)(i6 * 2 + 1));
		}

		for(i6 = 0; i6 < i1 / 8; ++i6) {
			this.trig[i4 + (i6 << 1)] = (float)Math.cos(3.141592653589793D / (double)i1 * (double)(i6 * 4 + 2));
			this.trig[i5 + (i6 << 1)] = (float)(-Math.sin(3.141592653589793D / (double)i1 * (double)(i6 * 4 + 2)));
		}

		i6 = (1 << this.log2n - 1) - 1;
		i2 = 1 << this.log2n - 2;

		for(i3 = 0; i3 < i1 / 8; ++i3) {
			i4 = 0;

			for(i5 = 0; i2 >>> i5 != 0; ++i5) {
				if((i2 >>> i5 & i3) != 0) {
					i4 |= 1 << i5;
				}
			}

			this.bitrev[i3 << 1] = ~i4 & i6;
			this.bitrev[(i3 << 1) + 1] = i4;
		}

		this.scale = 4.0F / (float)i1;
	}

	void clear() {
	}

	void forward(float[] f1, float[] f2) {
	}

	synchronized void backward(float[] f1, float[] f2) {
		if(this._x.length < this.n / 2) {
			this._x = new float[this.n / 2];
		}

		if(this._w.length < this.n / 2) {
			this._w = new float[this.n / 2];
		}

		float[] f3 = this._x;
		float[] f4 = this._w;
		int i5 = this.n >>> 1;
		int i6 = this.n >>> 2;
		int i7 = this.n >>> 3;
		int i8 = 1;
		int i9 = 0;
		int i10 = i5;

		int i11;
		for(i11 = 0; i11 < i7; ++i11) {
			i10 -= 2;
			f3[i9++] = -f1[i8 + 2] * this.trig[i10 + 1] - f1[i8] * this.trig[i10];
			f3[i9++] = f1[i8] * this.trig[i10 + 1] - f1[i8 + 2] * this.trig[i10];
			i8 += 4;
		}

		i8 = i5 - 4;

		for(i11 = 0; i11 < i7; ++i11) {
			i10 -= 2;
			f3[i9++] = f1[i8] * this.trig[i10 + 1] + f1[i8 + 2] * this.trig[i10];
			f3[i9++] = f1[i8] * this.trig[i10] - f1[i8 + 2] * this.trig[i10 + 1];
			i8 -= 4;
		}

		float[] f17 = this.mdct_kernel(f3, f4, this.n, i5, i6, i7);
		i9 = 0;
		i10 = i5;
		i11 = i6;
		int i13 = i6 - 1;
		int i14;
		int i15 = (i14 = i6 + i5) - 1;

		for(i5 = 0; i5 < i6; ++i5) {
			float f16 = f17[i9] * this.trig[i10 + 1] - f17[i9 + 1] * this.trig[i10];
			float f12 = -(f17[i9] * this.trig[i10] + f17[i9 + 1] * this.trig[i10 + 1]);
			f2[i11] = -f16;
			f2[i13] = f16;
			f2[i14] = f12;
			f2[i15] = f12;
			++i11;
			--i13;
			++i14;
			--i15;
			i9 += 2;
			i10 += 2;
		}

	}

	private float[] mdct_kernel(float[] f1, float[] f2, int i3, int i4, int i5, int i6) {
		int i7 = i5;
		int i8 = 0;
		int i9 = i4;

		int i10;
		for(i10 = 0; i10 < i5; ++i10) {
			float f11 = f1[i7] - f1[i8];
			f2[i5 + i10] = f1[i7++] + f1[i8++];
			float f12 = f1[i7] - f1[i8];
			i9 -= 4;
			f2[i10++] = f11 * this.trig[i9] + f12 * this.trig[i9 + 1];
			f2[i10] = f12 * this.trig[i9] - f11 * this.trig[i9 + 1];
			f2[i5 + i10] = f1[i7++] + f1[i8++];
		}

		int i13;
		float f14;
		float f15;
		float f16;
		float f17;
		int i23;
		int i24;
		for(i10 = 0; i10 < this.log2n - 3; ++i10) {
			i23 = i3 >>> i10 + 2;
			i24 = 1 << i10 + 3;
			i7 = i4 - 2;
			i9 = 0;

			for(i8 = 0; i8 < i23 >>> 2; ++i8) {
				i13 = i7;
				i5 = i7 - (i23 >> 1);
				f14 = this.trig[i9];
				f16 = this.trig[i9 + 1];
				i7 -= 2;
				++i23;

				for(int i18 = 0; i18 < 2 << i10; ++i18) {
					f17 = f2[i13] - f2[i5];
					f1[i13] = f2[i13] + f2[i5];
					++i13;
					float f10000 = f2[i13];
					++i5;
					f15 = f10000 - f2[i5];
					f1[i13] = f2[i13] + f2[i5];
					f1[i5] = f15 * f14 - f17 * f16;
					f1[i5 - 1] = f17 * f14 + f15 * f16;
					i13 -= i23;
					i5 -= i23;
				}

				--i23;
				i9 += i24;
			}

			float[] f21 = f2;
			f2 = f1;
			f1 = f21;
		}

		i10 = i3;
		i23 = 0;
		i24 = 0;
		i7 = i4 - 1;

		for(i5 = 0; i5 < i6; ++i5) {
			i8 = this.bitrev[i23++];
			i13 = this.bitrev[i23++];
			f14 = f2[i8] - f2[i13 + 1];
			f15 = f2[i8 - 1] + f2[i13];
			f16 = f2[i8] + f2[i13 + 1];
			f17 = f2[i8 - 1] - f2[i13];
			float f25 = f14 * this.trig[i10];
			float f19 = f15 * this.trig[i10++];
			float f20 = f14 * this.trig[i10];
			float f22 = f15 * this.trig[i10++];
			f1[i24++] = (f16 + f20 + f19) * 0.5F;
			f1[i7--] = (-f17 + f22 - f25) * 0.5F;
			f1[i24++] = (f17 + f22 - f25) * 0.5F;
			f1[i7--] = (f16 - f20 - f19) * 0.5F;
		}

		return f1;
	}
}
