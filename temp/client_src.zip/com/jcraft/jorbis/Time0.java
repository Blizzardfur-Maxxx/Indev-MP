package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class Time0 extends FuncTime {
	void pack(Object object1, Buffer buffer2) {
	}

	Object unpack(Info info1, Buffer buffer2) {
		return "";
	}

	Object look(DspState dspState1, InfoMode infoMode2, Object object3) {
		return "";
	}

	void free_info(Object object1) {
	}

	void free_look(Object object1) {
	}

	int inverse(Block block1, Object object2, float[] f3, float[] f4) {
		return 0;
	}
}
