package net.minecraft.client.model;

public final class ModelPig extends ModelQuadruped {
	public ModelPig() {
		super(6, 0.0F);
	}
}
