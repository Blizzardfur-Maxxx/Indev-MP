package net.minecraft.game.item.recipe;

public final class RecipesCrafting {
}
