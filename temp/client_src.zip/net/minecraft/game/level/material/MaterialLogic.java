package net.minecraft.game.level.material;

public final class MaterialLogic extends Material {
	public final boolean isSolid() {
		return false;
	}

	public final boolean getCanBlockGrass() {
		return false;
	}

	public final boolean getIsSolid() {
		return false;
	}
}
