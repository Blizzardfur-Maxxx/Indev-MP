package paulscode.sound;

public class SoundSystemLogger {
	public void message(String string1, int i2) {
		String string3 = "";

		for(int i4 = 0; i4 < i2; ++i4) {
			string3 = string3 + "    ";
		}

		string1 = string3 + string1;
		System.out.println(string1);
	}

	public void importantMessage(String string1, int i2) {
		String string3 = "";

		for(int i4 = 0; i4 < i2; ++i4) {
			string3 = string3 + "    ";
		}

		string1 = string3 + string1;
		System.out.println(string1);
	}

	public boolean errorCheck(boolean z1, String string2, String string3, int i4) {
		if(z1) {
			this.errorMessage(string2, string3, i4);
		}

		return z1;
	}

	public void errorMessage(String string1, String string2, int i3) {
		String string4 = "";

		for(int i5 = 0; i5 < i3; ++i5) {
			string4 = string4 + "    ";
		}

		string1 = string4 + "Error in class \'" + string1 + "\'";
		string2 = "    " + string4 + string2;
		System.out.println(string1);
		System.out.println(string2);
	}

	public void printStackTrace(Exception exception1, int i2) {
		this.printExceptionMessage(exception1, i2);
		this.importantMessage("STACK TRACE:", i2);
		if(exception1 != null) {
			StackTraceElement[] stackTraceElement5;
			if((stackTraceElement5 = exception1.getStackTrace()) != null) {
				for(int i4 = 0; i4 < stackTraceElement5.length; ++i4) {
					StackTraceElement stackTraceElement3;
					if((stackTraceElement3 = stackTraceElement5[i4]) != null) {
						this.message(stackTraceElement3.toString(), i2 + 1);
					}
				}

			}
		}
	}

	public void printExceptionMessage(Exception exception1, int i2) {
		this.importantMessage("ERROR MESSAGE:", i2);
		if(exception1.getMessage() == null) {
			this.message("(none)", i2 + 1);
		} else {
			this.message(exception1.getMessage(), i2 + 1);
		}
	}
}
