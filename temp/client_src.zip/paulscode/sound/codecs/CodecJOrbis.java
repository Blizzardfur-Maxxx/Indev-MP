package paulscode.sound.codecs;

import com.jcraft.jogg.Packet;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.SyncState;
import com.jcraft.jorbis.Block;
import com.jcraft.jorbis.Comment;
import com.jcraft.jorbis.DspState;
import com.jcraft.jorbis.Info;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownServiceException;
import javax.sound.sampled.AudioFormat;

import paulscode.sound.ICodec;
import paulscode.sound.SoundBuffer;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemLogger;

public class CodecJOrbis implements ICodec {
	private static final boolean GET = false;
	private static final boolean SET = true;
	private static final boolean XXX = false;
	private URL url;
	private URLConnection urlConnection = null;
	private InputStream inputStream;
	private AudioFormat audioFormat;
	private boolean endOfStream = false;
	private boolean initialized = false;
	private byte[] buffer = null;
	private int bufferSize;
	private int count = 0;
	private int index = 0;
	private int convertedBufferSize;
	private float[][][] pcmInfo;
	private int[] pcmIndex;
	private Packet joggPacket = new Packet();
	private Page joggPage = new Page();
	private StreamState joggStreamState = new StreamState();
	private SyncState joggSyncState = new SyncState();
	private DspState jorbisDspState = new DspState();
	private Block jorbisBlock = new Block(this.jorbisDspState);
	private Comment jorbisComment = new Comment();
	private Info jorbisInfo = new Info();
	private SoundSystemLogger logger = SoundSystemConfig.getLogger();

	public void reverseByteOrder(boolean z1) {
	}

	public boolean initialize(URL uRL1) {
		this.initialized(true, false);
		if(this.joggStreamState != null) {
			this.joggStreamState.clear();
		}

		if(this.jorbisBlock != null) {
			this.jorbisBlock.clear();
		}

		if(this.jorbisDspState != null) {
			this.jorbisDspState.clear();
		}

		if(this.jorbisInfo != null) {
			this.jorbisInfo.clear();
		}

		if(this.joggSyncState != null) {
			this.joggSyncState.clear();
		}

		if(this.inputStream != null) {
			try {
				this.inputStream.close();
			} catch (IOException iOException6) {
			}
		}

		this.url = uRL1;
		this.bufferSize = SoundSystemConfig.getStreamingBufferSize() / 2;
		this.buffer = null;
		this.count = 0;
		this.index = 0;
		this.joggStreamState = new StreamState();
		this.jorbisBlock = new Block(this.jorbisDspState);
		this.jorbisDspState = new DspState();
		this.jorbisInfo = new Info();
		this.joggSyncState = new SyncState();

		try {
			this.urlConnection = uRL1.openConnection();
		} catch (UnknownServiceException unknownServiceException4) {
			this.errorMessage("Unable to create a UrlConnection in method \'initialize\'.");
			this.printStackTrace(unknownServiceException4);
			this.cleanup();
			return false;
		} catch (IOException iOException5) {
			this.errorMessage("Unable to create a UrlConnection in method \'initialize\'.");
			this.printStackTrace(iOException5);
			this.cleanup();
			return false;
		}

		if(this.urlConnection != null) {
			try {
				this.inputStream = this.urlConnection.getInputStream();
			} catch (IOException iOException3) {
				this.errorMessage("Unable to acquire inputstream in method \'initialize\'.");
				this.printStackTrace(iOException3);
				this.cleanup();
				return false;
			}
		}

		this.endOfStream(true, false);
		this.joggSyncState.init();
		this.joggSyncState.buffer(this.bufferSize);
		this.buffer = this.joggSyncState.data;

		try {
			if(!this.readHeader()) {
				this.errorMessage("Error reading the header");
				return false;
			}
		} catch (IOException iOException7) {
			this.errorMessage("Error reading the header");
			return false;
		}

		this.convertedBufferSize = this.bufferSize << 1;
		this.jorbisDspState.synthesis_init(this.jorbisInfo);
		this.jorbisBlock.init(this.jorbisDspState);
		int i8 = this.jorbisInfo.channels;
		int i2 = this.jorbisInfo.rate;
		this.audioFormat = new AudioFormat((float)i2, 16, i8, true, false);
		this.pcmInfo = new float[1][][];
		this.pcmIndex = new int[this.jorbisInfo.channels];
		this.initialized(true, true);
		return true;
	}

	public boolean initialized() {
		return this.initialized(false, false);
	}

	public SoundBuffer read() {
		byte[] b1;
		return (b1 = this.readBytes()) == null ? null : new SoundBuffer(b1, this.audioFormat);
	}

	public SoundBuffer readAll() {
		byte[] b1 = this.readBytes();

		while(!this.endOfStream(false, false) && ((b1 = appendByteArrays(b1, this.readBytes())) == null || b1.length < SoundSystemConfig.getMaxFileSize())) {
		}

		return new SoundBuffer(b1, this.audioFormat);
	}

	public boolean endOfStream() {
		return this.endOfStream(false, false);
	}

	public void cleanup() {
		this.joggStreamState.clear();
		this.jorbisBlock.clear();
		this.jorbisDspState.clear();
		this.jorbisInfo.clear();
		this.joggSyncState.clear();
		if(this.inputStream != null) {
			try {
				this.inputStream.close();
			} catch (IOException iOException1) {
			}
		}

		this.joggStreamState = null;
		this.jorbisBlock = null;
		this.jorbisDspState = null;
		this.jorbisInfo = null;
		this.joggSyncState = null;
		this.inputStream = null;
	}

	public AudioFormat getAudioFormat() {
		return this.audioFormat;
	}

	private boolean readHeader() {
		this.index = this.joggSyncState.buffer(this.bufferSize);
		int i1;
		if((i1 = this.inputStream.read(this.joggSyncState.data, this.index, this.bufferSize)) < 0) {
			i1 = 0;
		}

		this.joggSyncState.wrote(i1);
		if(this.joggSyncState.pageout(this.joggPage) != 1) {
			if(i1 < this.bufferSize) {
				return true;
			} else {
				this.errorMessage("Ogg header not recognized in method \'readHeader\'.");
				return false;
			}
		} else {
			this.joggStreamState.init(this.joggPage.serialno());
			this.jorbisInfo.init();
			this.jorbisComment.init();
			if(this.joggStreamState.pagein(this.joggPage) < 0) {
				this.errorMessage("Problem with first Ogg header page in method \'readHeader\'.");
				return false;
			} else if(this.joggStreamState.packetout(this.joggPacket) != 1) {
				this.errorMessage("Problem with first Ogg header packet in method \'readHeader\'.");
				return false;
			} else if(this.jorbisInfo.synthesis_headerin(this.jorbisComment, this.joggPacket) < 0) {
				this.errorMessage("File does not contain Vorbis header in method \'readHeader\'.");
				return false;
			} else {
				int i2 = 0;

				while(i2 < 2) {
					label71:
					while(true) {
						do {
							if(i2 >= 2 || (i1 = this.joggSyncState.pageout(this.joggPage)) == 0) {
								this.index = this.joggSyncState.buffer(this.bufferSize);
								if((i1 = this.inputStream.read(this.joggSyncState.data, this.index, this.bufferSize)) < 0) {
									i1 = 0;
								}

								if(i1 == 0 && i2 < 2) {
									this.errorMessage("End of file reached before finished readingOgg header in method \'readHeader\'");
									return false;
								}

								this.joggSyncState.wrote(i1);
								continue label71;
							}
						} while(i1 != 1);

						this.joggStreamState.pagein(this.joggPage);

						while(i2 < 2 && (i1 = this.joggStreamState.packetout(this.joggPacket)) != 0) {
							if(i1 == -1) {
								this.errorMessage("Secondary Ogg header corrupt in method \'readHeader\'.");
								return false;
							}

							this.jorbisInfo.synthesis_headerin(this.jorbisComment, this.joggPacket);
							++i2;
						}
					}
				}

				this.index = this.joggSyncState.buffer(this.bufferSize);
				this.buffer = this.joggSyncState.data;
				return true;
			}
		}
	}

	private byte[] readBytes() {
		if(!this.initialized(false, false)) {
			return null;
		} else if(this.endOfStream(false, false)) {
			return null;
		} else {
			byte[] b1 = null;
			switch(this.joggSyncState.pageout(this.joggPage)) {
			case -1:
			case 0:
				this.endOfStream(true, true);
				break;
			case 1:
				this.joggStreamState.pagein(this.joggPage);
				if(this.joggPage.granulepos() == 0L) {
					this.endOfStream(true, true);
				} else {
					label47:
					while(true) {
						switch(this.joggStreamState.packetout(this.joggPacket)) {
						case -1:
						case 0:
							if(this.joggPage.eos() != 0) {
								this.endOfStream(true, true);
							}
							break label47;
						case 1:
							b1 = appendByteArrays(b1, this.decodeCurrentPacket());
						}
					}
				}
			}

			if(!this.endOfStream(false, false)) {
				this.index = this.joggSyncState.buffer(this.bufferSize);
				if(this.index == -1) {
					this.endOfStream(true, true);
				} else {
					this.buffer = this.joggSyncState.data;

					try {
						this.count = this.inputStream.read(this.buffer, this.index, this.bufferSize);
					} catch (Exception exception3) {
						this.printStackTrace(exception3);
						return b1;
					}

					this.joggSyncState.wrote(this.count);
					if(this.count == 0) {
						this.endOfStream(true, true);
					}
				}
			}

			return b1;
		}
	}

	private byte[] decodeCurrentPacket() {
		byte[] b1 = new byte[this.convertedBufferSize];
		if(this.jorbisBlock.synthesis(this.joggPacket) == 0) {
			this.jorbisDspState.synthesis_blockin(this.jorbisBlock);
		}

		int i3 = this.convertedBufferSize / (this.jorbisInfo.channels << 1);
		int i4 = 0;

		int i2;
		while(i4 < this.convertedBufferSize && (i2 = this.jorbisDspState.synthesis_pcmout(this.pcmInfo, this.pcmIndex)) > 0) {
			if(i2 < i3) {
				i2 = i2;
			} else {
				i2 = i3;
			}

			for(int i5 = 0; i5 < this.jorbisInfo.channels; ++i5) {
				int i6 = i5 << 1;

				for(int i7 = 0; i7 < i2; ++i7) {
					int i8;
					if((i8 = (int)(this.pcmInfo[0][i5][this.pcmIndex[i5] + i7] * 32767.0F)) > 32767) {
						i8 = 32767;
					}

					if(i8 < -32768) {
						i8 = -32768;
					}

					if(i8 < 0) {
						i8 |= 32768;
					}

					b1[i4 + i6] = (byte)i8;
					b1[i4 + i6 + 1] = (byte)(i8 >>> 8);
					i6 += 2 * this.jorbisInfo.channels;
				}
			}

			i4 += i2 * this.jorbisInfo.channels << 1;
			this.jorbisDspState.synthesis_read(i2);
		}

		return trimArray(b1, i4);
	}

	private synchronized boolean initialized(boolean z1, boolean z2) {
		if(z1) {
			this.initialized = z2;
		}

		return this.initialized;
	}

	private synchronized boolean endOfStream(boolean z1, boolean z2) {
		if(z1) {
			this.endOfStream = z2;
		}

		return this.endOfStream;
	}

	private static byte[] trimArray(byte[] b0, int i1) {
		byte[] b2 = null;
		if(b0 != null && b0.length > i1) {
			b2 = new byte[i1];
			System.arraycopy(b0, 0, b2, 0, i1);
		}

		return b2;
	}

	private static byte[] appendByteArrays(byte[] b0, byte[] b1) {
		if(b0 == null && b1 == null) {
			return null;
		} else {
			byte[] b2;
			if(b0 == null) {
				b2 = new byte[b1.length];
				System.arraycopy(b1, 0, b2, 0, b1.length);
			} else if(b1 == null) {
				b2 = new byte[b0.length];
				System.arraycopy(b0, 0, b2, 0, b0.length);
			} else {
				b2 = new byte[b0.length + b1.length];
				System.arraycopy(b0, 0, b2, 0, b0.length);
				System.arraycopy(b1, 0, b2, b0.length, b1.length);
			}

			return b2;
		}
	}

	private void errorMessage(String string1) {
		this.logger.errorMessage("CodecJOrbis", string1, 0);
	}

	private void printStackTrace(Exception exception1) {
		this.logger.printStackTrace(exception1, 1);
	}
}
